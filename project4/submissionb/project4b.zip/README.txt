Partner: William Seto 803885258

We fixed some problems we had with the item page that we didn't finish for part a.
Some of the websites we looked at to parse the XML:
http://www.mkyong.com/java/how-to-read-xml-file-in-java-jdom-example/

In addition, we made decided not to show a map if given a bad location,
decided to not show buy Price if it’s not given, and decided to not show
the description if it’s not given.
