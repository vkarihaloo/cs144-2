William Seto 803885258

To escape the XML characters, we used a function online and put it in a helper function called for_XML. We also escaped slashes (\) to (\\), but weren't sure if this was needed.
