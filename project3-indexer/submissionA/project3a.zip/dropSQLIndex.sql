DROP INDEX sellerindex ON Items;
DROP INDEX buypriceindex ON Items;
DROP INDEX bidderindex ON Bids;
DROP INDEX endtimeindex ON Items;